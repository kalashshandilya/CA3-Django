from django.apps import AppConfig


class EthAppConfig(AppConfig):
    name = 'eth_app'
